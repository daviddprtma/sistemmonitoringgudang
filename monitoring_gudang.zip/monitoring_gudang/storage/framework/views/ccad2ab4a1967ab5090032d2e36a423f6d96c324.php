<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel7\kp\monitoring_gudang\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>