<?php $__env->startSection('aside'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\kp\monitoring_gudang\resources\views/welcome.blade.php ENDPATH**/ ?>