@extends('layouts.admin')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        {{-- <div class="col-md-8">
            WELCOME TO PT.BERKAT KESELAMATAN DUNIA 
        </div>
        <div class="col-md-8">
        Akses Cepat: 
            <a href="{{url('dashboards')}}">Dashboard</a>
        </div> --}}
    </div>
</div>
@endsection
